# Daily Cafe Website Project

This is a 5-page HTML-based website for a coffee shop located in East London. The project focuses on semantic HTML structure, navigation, and professional layout without the use of external CSS [cite: 8, 38, 47, 57].

## Student Information
* **Name:** RETHABILE EDEN LENONG [cite: 3]
* **Student Number:** ST10528266 [cite: 3]
* **Institution:** Rosebank College [cite: 3]

## Website Features
* **Home Page:** Includes a hero image, introduction, and a Call to Action [cite: 39].
* **About Us:** Details the mission and history of Daily Cafe [cite: 40].
* **Menu:** Provides a list of coffee and food products for online viewing [cite: 41, 24].
* **Enquiry:** Allows customers to submit inquiries via the contact page [cite: 29].
* **Contact:** Includes location details and contact information [cite: 42, 37].

## Technologies Used
* HTML5 for structural design [cite: 57].
* Git and GitHub for version control and project hosting [cite: 58, 59].

## References
* Canva, 2025. *Colour Theory and Design Basics*. [online] Available at: <https://www.canva.com> [Accessed 20 April 2026] [cite: 134].
* Google LLC, 2025. *Web Design Basics*. [online] Available at: <https://www.google.com> [Accessed 20 April 2026] [cite: 130].
* HubSpot, 2025. *Website Design and User Experience Principles*. [online] Available at: <https://www.hubspot.com> [Accessed 20 April 2026] [cite: 133].
* MDN Web Docs, 2025. *Web Development Guide*. [online] Available at: <https://developer.mozilla.org> [Accessed 20 April 2026] [cite: 132].
* W3Schools, 2025. *HTML, CSS and JavaScript Tutorials*. [online] Available at: <https://www.w3schools.com> [Accessed 20 April 2026] [cite: 131].
